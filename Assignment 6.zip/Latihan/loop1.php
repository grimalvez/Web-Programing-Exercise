<?php
	session_start();
	$y=$_SESSION['var'];
	if (isset($_POST['submit'])){
	$jawab = $_POST['fname'];
	if ($jawab == $y){
		include 'main.php';
		echo "<p>Benar jawabannya adalah $jawab</p>";
	}else{
		include 'main.php';
		if ($jawab > $hasil){
			echo "<p>Jawaban anda salah ! bilangan tebakan anda masih terlalu tinggi</p>";
		}else{
			echo "<p>Jawaban anda salah ! bilangan tebakan anda masih terlalu rendah</p>";
		}
	}
	}
?>