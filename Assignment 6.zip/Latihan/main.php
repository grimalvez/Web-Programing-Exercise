<!DOCTYPE html>
<html>
<head>
	<title>Math</title>
	<style type="text/css">
		* {
			margin: 5px;
			padding: 5px;
			font-family: 'JetBrains Mono', monospace;
		}
	</style>
</head>

<body>
	<?php
		if(!isset($_SESSION)){ 
			session_start(); 
		}
		$angka1 = rand(0, 100);
		$angka2 = rand(0, 100);
		$hasil = $angka1 + $angka2;
		$_SESSION['var']=$hasil;
		
		echo "<p>Hallo, nama saya Mr. PHP. Saya telah memilih secara random sebuah bilangan bulat. Silakan
		Anda menebak ya!<p>";
		echo "Berapa hasil dari $angka1 + $angka2 ?  <br>";
	?>
	<form action="loop1.php" method="post">
	<input type="text" name="fname">
	<input type="submit" name="submit" value="submit">
	</form>
</body>
</html>