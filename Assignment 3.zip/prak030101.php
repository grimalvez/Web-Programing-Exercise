
<?php
echo str_repeat("Hello", 3);
?>