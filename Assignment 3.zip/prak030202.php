<?php

function hitungDenda($tglHarusKembali, $tglKembali){
	$x = date_create($tglHarusKembali);
	$y = date_create($tglKembali);
	
	$tglSelisih = date_diff($x, $y);
	$x = $tglSelisih->format("%a");
	$denda = (int)$x * 3000;
	$y = "Besarnya denda adalah: Rp. $denda,-";
	return $y;
}

echo hitungDenda("2021-01-06", "2021-01-10");
?>