<?php
echo "<h2>DATA MAHASISWA</h2>";
$namaFile = "datamahasiswa.dat";
$myfile = fopen($namaFile, "r") or die("Tidak bisa buka file!");
$x = 0;
echo"<table>";
echo"<tr>";
echo"<th>No</th>";
echo"<th>NIM</th>";
echo"<th>Nama Mhs</th>";
echo"<th>Tgl Lahir</th>";
echo"<th>Tempat Lahir</th>";
echo"<th>Usia(Tahun)</th>";
echo"</tr>";
echo"</table>";

while (!feof($myfile)){
	$data = fgets($myfile);
	$pemecah = explode("|", "$data ");
	$x = $x + 1;
	array_push($pemecah, $x);
	
	$tgl = explode("-",$pemecah[2]);
    $yearBorn = date($tgl[0]);
    $yearNow = date("Y");
    $result = $yearNow - $yearBorn;
    array_push($pemecah, $result);
	
	echo "<table>";
	echo "<tr>";
	echo "<td>$pemecah[4]</td>";
	echo "<td>$pemecah[0]</td>";
	echo "<td>$pemecah[1]</td>";
	echo "<td>$pemecah[2]</td>";
	echo "<td>$pemecah[3]</td>";
	echo "<td>$pemecah[5]</td>";
	echo "</tr>";
	echo "</table>";
}
echo "<br>Jumlah data : $x";

?>

<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
  text-align: center;
}
table{
	width:100% ;
}
th, td{
	width:10%
}
h2{
	text-align:center;
}
</style>
</head>
<body>
  
</body>
</html>
