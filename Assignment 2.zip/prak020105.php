<html>
 	<head>Headings</head>
 	<body>
 	<?php
		$i=0;
 		do{
			$i = $i + 1;
 			if($i == 2 or $i == 4 or $i== 6){
				echo "<h$i><font color=red>Heading</font></h$i>";
			} else {
				echo "<h$i>Heading</h$i>";
			}
 		}while($i <= 5)
 	?>
 	</body>
</html>