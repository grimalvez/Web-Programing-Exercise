<html>
 	<head>Headings</head>
 	<body>
 	<?php
 		for($i=1; $i <= 5; $i++){
 			if($i == 2 or $i == 4){
				echo "<h$i><font color=red>Heading</font></h$i>";
			} else {
				echo "<h$i>Heading</h$i>";
			}
 		}
 	?>
 	</body>
</html>