<html>
 	<head>Headings</head>
 	<body>
 	<?php
 		for($i=1; $i <= 3; $i++){
 			echo "<h$i>Heading</h$i>";
 		}
 	?>
 	</body>
</html>
