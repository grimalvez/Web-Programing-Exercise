<html>
 	<head>Heading</head>
 	<body>
 	<?php
 		echo "<h1>Heading 1</h1>";
		echo "<h2>Heading 2</h2>";
		echo "<h3>Heading 3</h3>";
		echo "<h4>Heading 4</h4>";
		echo "<h5>Heading 5</h5>";
		echo "<h6>Heading 6</h6>";
 	?>
 	</body>
</html>
