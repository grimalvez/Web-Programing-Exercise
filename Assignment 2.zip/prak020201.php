<?php
$baris = 4;
$kolom = 5;
$number = 1;
echo "<table border='1'>";
for($i =0; $i < $baris; $i++){
 	echo "<tr>";
 	for ($j = 0; $j < $kolom; $j++){
 		echo "<th>";
		if($number % 2){
			echo"<font color=red>$number</font>";
		} else {
			echo"<background = blue> $number </background>";
		}
		$number = $number + 1;
 	}
  	echo "</tr>";
}
echo "</table>";
?>
