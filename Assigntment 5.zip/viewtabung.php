<?php
echo "<h2>DATA UKURAN TABUNG</h2>";
$namaFile = "datatabung.dat";
$myfile = fopen($namaFile, "r") or die("Tidak bisa buka file!");

echo"<table>";
echo"<tr>";
echo"<th>Nama Tabung</th>";
echo"<th>Diameter</th>";
echo"<th>Tinggi</th>";
echo"<th>Luas</th>";
echo"</tr>";
echo"</table>";

while (!feof($myfile)){
	$data = fgets($myfile);
	$pemecah = explode(",", "$data");
	$luas = $pemecah[1] * 3.14 * $pemecah[2] * ($pemecah[1] + $pemecah[2]);
	echo "<table>";
	echo "<tr>";
	echo "<td>$pemecah[0]</td>";
	echo "<td>$pemecah[1]</td>";
	echo "<td>$pemecah[2]</td>";
	echo "<td>$luas</td>";
	echo "</tr>";
	echo "</table>";
}

?>

<!DOCTYPE html>
<html>
<head>
<style>
table, th, td {
  border: 1px solid black;
  text-align: center;
}
table{
	width:100% ;
}
th, td{
	width:10%
}
h2{
	text-align:center;
}
</style>
</head>
<body>
  
</body>
</html>
